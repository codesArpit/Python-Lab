#Case 3 Overloading == Operator in Rectangle Class
class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def __eq__(self, other):
        return self.area() == other.area()

    def __str__(self):
        return f"Rectangle with length {self.length} and width {self.width}"


r1 = Rectangle(4, 5)
r2 = Rectangle(2, 10)
print(r1 == r2)  
