#Case 2
class Distance:
    def __init__(self, feet, inches):
        self.feet = feet
        self.inches = inches

    def __mul__(self, scalar):
        total_inches = (self.feet * 12 + self.inches) * scalar
        new_feet = total_inches // 12
        new_inches = total_inches % 12
        return Distance(int(new_feet), int(new_inches))

    def __str__(self):
        return f"{self.feet} feet, {self.inches} inches"



d1 = Distance(5, 8)
d2 = d1 * 3
print(d2)  
